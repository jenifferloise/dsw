package atividade.model;

public class DoacaoModel {
    private String nome;
    private double valor;
    private int ag;
    private int num;

    public DoacaoModel(String nome, double valor, int ag, int num) {
        this.nome = nome;
        this.valor = valor;
        this.ag = ag;
        this.num = num;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public int getAg() {
        return ag;
    }

    public void setAg(int ag) {
        this.ag = ag;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
}
