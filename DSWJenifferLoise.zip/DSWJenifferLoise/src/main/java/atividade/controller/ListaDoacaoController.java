package atividade.controller;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import atividade.model.DoacaoModel;
@WebServlet(name = "ListaDoacaoController", value="/lista")
public class ListaDoacaoController extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<DoacaoModel> doacoes = (List<DoacaoModel>) request.getSession().getAttribute("doacoes");
        if (doacoes==null){
            doacoes= new ArrayList<>();
            request.getSession().setAttribute("doacoes",doacoes);
        }
        getServletContext().getRequestDispatcher("/view/lista.jsp").forward(request,response);
    }
}
